Write-Host "Startup script executing"
# Set the desktop path explicitly for the Administrator user
$desktop = "C:\Users\Administrator\Desktop"
Write-Host "Using Desktop path: $desktop"

# Define the source path for the JupyterLab shortcut
$jupyterShortcutSrc = "C:\JupyterLab.lnk"  # Adjust the file name if needed

# Step 1: Copy the JupyterLab shortcut to the Desktop
if (Test-Path $jupyterShortcutSrc) {
    $jupyterShortcutDest = "$desktop\JupyterLab.lnk"
    Copy-Item $jupyterShortcutSrc -Destination $jupyterShortcutDest -Force
    Write-Host "JupyterLab shortcut copied to Desktop."
} else {
    Write-Host "JupyterLab shortcut not found at the specified location."
}

# Define the RStudio executable and icon locations
$rStudioExe = "C:\Program Files\RStudio\rstudio.exe"  # Path as per your requirement
$rStudioIcon = "C:\Program Files\ResearchGateway\rstudio.ico"  # Custom icon path as per your requirement

# Step 2: Create RStudio shortcut on the Desktop
$WScriptShell = New-Object -ComObject WScript.Shell
$rStudioShortcut = $WScriptShell.CreateShortcut("$desktop\RStudio.lnk")
$rStudioShortcut.TargetPath = $rStudioExe
$rStudioShortcut.IconLocation = $rStudioIcon  # Set the custom icon for RStudio
$rStudioShortcut.Save()

Write-Host "RStudio shortcut created on the Desktop."

Write-Host "Script execution completed."

$WScriptShell.CreateShortcut("$desktop\JupyterLab.lnk").IconLocation = "C:\Program Files\ResearchGateway\jupyterLab.ico"
